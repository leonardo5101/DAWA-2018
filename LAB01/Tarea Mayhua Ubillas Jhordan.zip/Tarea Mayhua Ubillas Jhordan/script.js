var http = require('http');
var url = require('url');
fs = require('fs');
var html = fs.readFileSync('./index.html');

http.createServer(function(solicitud,respuesta){
	objURL = url.parse(solicitud.url);
	ruta = objURL.pathname;

	fs.readFile(ruta,function(error,html){
		respuesta.write(html);
	respuesta.end();
	});	
}).listen(8888);
